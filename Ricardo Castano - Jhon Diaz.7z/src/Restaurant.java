public class Restaurant {

    Restaurant(){
    }
    public static void displayBurgers(){
        System.out.println("\t\t Brampton Burger\n\t\t ```````````````\n----------------------------------------\n");
    }

}
