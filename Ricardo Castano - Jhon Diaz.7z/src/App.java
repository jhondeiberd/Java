import java.util.Scanner;
import java.util.InputMismatchException;

public class App {
    public static void main(String[] args) {

        Restaurant.displayBurgers();

        Burger b = new BasicBurger();
        Burger b1 = new HealthyBurger();
        Burger b2 = new DeluxeBurger();
        Topping t = new Topping("Tomato", 0.27);
        Topping t1 = new Topping("Lettuce", 0.72);
        Topping t2 = new Topping("Cheese", 1.13);
        Topping t3 = new Topping("Carrot", 2.75);
        Topping t4 = new Topping("Thats all", 4.87);

        System.out.println("\t\t Menu\n----------------------------------------\n");
        System.out.println("Select the hamburger:");
        System.out.println(b);
        System.out.println(b1);
        System.out.println(b2);

        Scanner IO = new Scanner(System.in);
        boolean exit = false;
        int choice = 0;
        while (!exit) {
            System.out.println("1– Basic hamburger\n2– Healthy hamburger\n3– Deluxe hamburger\n4– Exit");
            try {
                choice = IO.nextInt();
                switch (choice) {
                    case 1:
                        System.out.println("Select 4 toppings:");
                        System.out.println(t);
                        System.out.println(t1);
                        System.out.println(t2);
                        System.out.println(t3);
                        System.out.println(t4);
                        break;
                    case 2:
                        System.out.println("Select 6 toppings:");
                        System.out.println(t);
                        System.out.println(t1);
                        System.out.println(t2);
                        System.out.println(t3);
                        System.out.println(t4);
                        break;
                    case 3:
                        System.out.println("Select 2 toppings:");
                        System.out.println(t);
                        System.out.println(t1);
                        System.out.println(t2);
                        System.out.println(t3);
                        System.out.println(t4);
                        break;
                    case 4:
                        exit = true;
                        break;
                    default:
                        System.out.println("Only Numbers between 1 y 4");
                }
            }catch (InputMismatchException e) {
                System.out.println("Enter only numbers");
                IO.next();
            }
        }
    }
}